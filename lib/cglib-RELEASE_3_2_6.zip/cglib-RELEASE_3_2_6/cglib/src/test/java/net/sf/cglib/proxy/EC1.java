package net.sf.cglib.proxy;

public class EC1 extends EB implements Comparable{
	private String address;
	private ED ed;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public ED getED() {
		return ed;
	}

	public void setED(ED ed) {
		this.ed = ed;
	}
}

