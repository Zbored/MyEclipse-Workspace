package net.sf.cglib.proxy;

public interface DI2 {
    public String derby();
}
